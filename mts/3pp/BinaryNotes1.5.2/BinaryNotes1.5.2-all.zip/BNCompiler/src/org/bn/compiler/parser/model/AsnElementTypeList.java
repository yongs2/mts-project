package org.bn.compiler.parser.model;

//~--- JDK imports ------------------------------------------------------------

import java.util.ArrayList;

//~--- classes ----------------------------------------------------------------

public class AsnElementTypeList {
    public ArrayList elements;

    //~--- constructors -------------------------------------------------------

    // Default Constructor
    public AsnElementTypeList() {
        elements = new ArrayList();
    }

    //~--- methods ------------------------------------------------------------

    public String toString() {
        String ts = "";

        return ts;
    }
}
